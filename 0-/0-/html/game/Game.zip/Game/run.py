# coding:utf-8

import BaseHTTPServer, SimpleHTTPServer

from SocketServer import ThreadingMixIn

import ssl

from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler

def main():

httpd = ThreadedHTTPSServer(('127.0.0.1', 31001), WelcomeHandler)

httpd.socket = ssl.wrap_socket(httpd.socket, \

certfile='nfvo_https.pem', \

keyfile="nfvo_https.key", \

server_side=True)

try:

httpd.serve_forever()

except(KeyboardInterrupt):

print "\nStop web server ..."

class ThreadedHTTPSServer(ThreadingMixIn, HTTPServer):

""" this is a example https server"""

class WelcomeHandler(BaseHTTPRequestHandler):

def response(self, code, htmlPage):

self.send_response(code)

self.send_header("Content-type", "text/html")

self.end_headers()

self.wfile.write(htmlPage)

def do_GET(self):

if self.path == "/hello":

self.response(200, "Hello World.\n")

return

self.response(200, "GET request.\n")

def do_POST(self):

self.response(200, "POST request.\n")

def do_PUT(self):

self.response(200, "PUT request.\n")

if __name__ == '__main__':

main()